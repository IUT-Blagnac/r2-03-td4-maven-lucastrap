/**
 * Ceci est une classe de test qui ne fait pas grand chose
 * @author JMB
 * @author LC
 */
class HelloJava {
    public static void main(String[] args) {
		System.out.println("Hello Blagnac");


	}

	public void afficherCancan(){
	}
}